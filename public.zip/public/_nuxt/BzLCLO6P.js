import"#entry";const s=globalThis.setInterval;export{s};
